var items = ["Brazil", "Japan", "Korea"]; // First we create an array.
	for( var i = 0; i < items.length; i++ ) {
	alert( items[i] ); // This will alert each item in the array.
